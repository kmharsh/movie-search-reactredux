## App Overview

A react redux application that allows users to search for movies and view the selected movie's information.
Libraries used: Redux, React-Redux, React-router-dom, React-loader-spinner, Redux-thunk

You can view this site [here](https://moviezone7.netlify.app/).<br/>

## Running the Project

In the project directory, run the following commands:

### `npm install`

### `npm start`
