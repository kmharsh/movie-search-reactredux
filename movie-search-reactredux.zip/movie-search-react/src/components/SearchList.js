import React from "react";

class SearchList extends React.Component {
  render() {
    return (
      //
      <div>Search list</div>
    );
  }
}

export default SearchList;
